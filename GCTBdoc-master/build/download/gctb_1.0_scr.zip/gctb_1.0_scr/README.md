# GCTB
Genome-wide Complex Trait Bayesian analysis

### Overview
[GCTB](http://cnsgenomics.com/software/gctb) is a C++ software tool that comprises Bayesian mixed linear models for complex trait analyses using genome-wide SNPs.


### How to compile GCTB 1.0
GCTB 1.0 has dependencies on two C++ libraries i.e. Eigen3 and Boost.

To compile GCTB 1.0 on a Linux/Mac system, follow below steps:

1. Download [Eigen3](http://eigen.tuxfamily.org/index.php?title=Main_Page) and [Boost](http://www.boost.org/users/download/);
2. Edit their path in the enclosed Makefile (these two libraries themselves do not need to be compiled);
3. Switch "SYS" to "LINUX” or “MAC” in the Makefile;
4. Execute make command.


We have also included a Xcode (v7.3.1) project file for Mac system. To compile in the Xcode, follow below steps:

1. Click on the project in Xcode and then click on Build Settings;
2. Add “/usr/local/include” to “Search Paths – Header Search Paths”;
3. Add the paths of Eigen and Boost libraries to “Search Paths – Header Search Paths”;
4. Use Command+B to compile.


### How to run GCTB 1.0 

Use the command below (with the test dataset): 

`gctb --bfile data/1000G_eur_chr22 --pheno data/test.phen --bayes S --chain-length 1100 --burn-in 100 --out test`

An alternative way to run the program with the parameter settings is to use a input parameter file: 

`gctb --inp-file test.inp`

